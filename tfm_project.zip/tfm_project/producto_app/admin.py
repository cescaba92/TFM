from django.contrib import admin
from producto_app.models import TipoProducto
# Register your models here.

admin.site.register(TipoProducto)
