from django.contrib import admin
from basic_app.models import UserProfile
from basic_app.models import Rol
# Register your models here.

admin.site.register(UserProfile)
admin.site.register(Rol)