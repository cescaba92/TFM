from django.apps import AppConfig


class CadenaAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "cadena_app"
