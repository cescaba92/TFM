from django.contrib import admin
from suministro_app.models import (TipoProveedor,TipoSuministro)
# Register your models here.


admin.site.register(TipoProveedor)
admin.site.register(TipoSuministro)