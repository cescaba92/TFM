from django.apps import AppConfig


class SuministroAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "suministro_app"
